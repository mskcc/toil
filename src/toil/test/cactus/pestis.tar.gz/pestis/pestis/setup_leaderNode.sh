#!/bin/bash
sudo apt-get -y update
sudo apt-get -y install git
sudo apt-get -y install nano
virtualenv --system-site-packages cact_venv
source cact_venv/bin/activate
git clone https://github.com/ComparativeGenomicsToolkit/cactus
cd cactus
pip install --upgrade .

exit
